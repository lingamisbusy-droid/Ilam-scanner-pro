package com.ilam.scanner

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val blue = Color.rgb(49, 87, 200)
    private val ink = Color.rgb(28, 37, 61)
    private val muted = Color.rgb(111, 121, 143)
    private val bg = Color.rgb(245, 247, 252)
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var empty: TextView
    private var docs = mutableListOf<Doc>()

    private val scanLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val scan = GmsDocumentScanningResult.fromActivityResultIntent(result.data)
            if (scan != null) saveScan(scan)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        docs = loadDocs()
        buildHome()
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(24)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        brand.addView(label("ILAM SCANNER", 12, blue, true))
        brand.addView(label("Your documents, organised.", 22, ink, true))
        val badge = label("PDF  •  JPG", 11, blue, true).apply { setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(Color.rgb(230, 237, 255)) }
        top.addView(brand); top.addView(badge); content.addView(top)
        content.addView(label("Scan, save and share documents in seconds.", 14, muted, false).apply { setPadding(0, dp(8), 0, dp(20)) })

        val scanCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); setBackgroundColor(blue)
        }
        scanCard.addView(label("DOCUMENT SCANNER", 11, Color.WHITE, true))
        scanCard.addView(label("Turn paper into\nclean digital files", 24, Color.WHITE, true).apply { setPadding(0, dp(8), 0, dp(14)) })
        val scanBtn = Button(this).apply { text = "＋  Scan a document"; isAllCaps = false; textSize = 16f; setTextColor(blue); setOnClickListener { startScan() } }
        scanCard.addView(scanBtn)
        content.addView(scanCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(actionTile("▣", "Import & scan", "Choose gallery pages") { startScan() }, LinearLayout.LayoutParams(0, dp(104), 1f).apply { rightMargin = dp(7) })
        actions.addView(actionTile("PDF", "PDF tools", "Open saved PDFs") { showPdfTools() }, LinearLayout.LayoutParams(0, dp(104), 1f).apply { leftMargin = dp(7) })
        content.addView(actions)

        val heading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(24), 0, dp(10)) }
        heading.addView(label("Recent documents", 18, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        heading.addView(label("${docs.size} saved", 12, muted, false))
        content.addView(heading)
        search = EditText(this).apply {
            hint = "Search documents"; textSize = 14f; singleLine = true; setPadding(dp(14), 0, dp(14), 0)
            setBackgroundColor(Color.WHITE); addTextChangedListener(SimpleWatcher { renderDocs() })
        }
        content.addView(search, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(10) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        empty = label("No documents yet. Scan your first page to get started.", 14, muted, false).apply { gravity = Gravity.CENTER; setPadding(dp(20), dp(28), dp(20), dp(28)) }
        content.addView(list); content.addView(empty)
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val bottom = TextView(this).apply { text = "ILAM SCANNER     •     PRIVATE ON-DEVICE STORAGE"; textSize = 10f; letterSpacing = .6f; gravity = Gravity.CENTER; setTextColor(muted); setPadding(0, dp(12), 0, dp(14)); setBackgroundColor(Color.WHITE) }
        root.addView(bottom)
        setContentView(root)
        renderDocs()
    }

    private fun actionTile(icon: String, title: String, sub: String, click: () -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(10), dp(10)); setBackgroundColor(Color.WHITE); setOnClickListener { click() }
            addView(label(icon, 18, blue, true)); addView(label(title, 14, ink, true).apply { setPadding(0, dp(5), 0, dp(2)) }); addView(label(sub, 11, muted, false))
        }
    }

    private fun startScan() {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(100)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF, GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options).getStartScanIntent(this)
            .addOnSuccessListener { sender -> scanLauncher.launch(IntentSenderRequest.Builder(sender).build()) }
            .addOnFailureListener { e -> toast("Scanner unavailable: ${e.localizedMessage ?: "Please try again."}") }
    }

    private fun saveScan(scan: GmsDocumentScanningResult) {
        try {
            val dir = File(filesDir, "documents").apply { mkdirs() }
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val pageFiles = mutableListOf<String>()
            scan.pages?.forEachIndexed { i, page ->
                val file = File(dir, "Ilam_${stamp}_page_${i + 1}.jpg")
                contentResolver.openInputStream(page.imageUri)?.use { input -> FileOutputStream(file).use { input.copyTo(it) } }
                if (file.exists()) pageFiles.add(file.name)
            }
            val pdfFile = scan.pdf?.let { pdf ->
                File(dir, "Ilam_${stamp}.pdf").also { file ->
                    contentResolver.openInputStream(pdf.uri)?.use { input -> FileOutputStream(file).use { input.copyTo(it) } }
                }
            }
            if (pdfFile == null || !pdfFile.exists()) { toast("Scan received, but PDF could not be saved."); return }
            val doc = Doc("doc_$stamp", "Scanned Document", pdfFile.name, pageFiles, scan.pdf?.pageCount ?: pageFiles.size, System.currentTimeMillis())
            docs.add(0, doc); persistDocs(); renderDocs(); toast("Document saved successfully")
        } catch (e: Exception) { toast("Could not save scan: ${e.localizedMessage}") }
    }

    private fun renderDocs() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val query = if (::search.isInitialized) search.text.toString().trim().lowercase(Locale.getDefault()) else ""
        val shown = docs.filter { it.name.lowercase(Locale.getDefault()).contains(query) }
        empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        if (shown.isEmpty() && docs.isNotEmpty() && query.isNotEmpty()) empty.text = "No matching documents found."
        else empty.text = "No documents yet. Scan your first page to get started."
        shown.forEach { doc ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(8), dp(10)); setBackgroundColor(Color.WHITE) }
            val icon = TextView(this).apply { text = "PDF"; textSize = 11f; setTextColor(Color.rgb(194, 54, 65)); setTypeface(null, 1); gravity = Gravity.CENTER; setBackgroundColor(Color.rgb(255, 237, 239)); setPadding(dp(10), dp(12), dp(10), dp(12)) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(4), 0) }
            info.addView(label(doc.name, 14, ink, true)); info.addView(label("${doc.pageCount} pages  •  ${formatDate(doc.created)}", 11, muted, false).apply { setPadding(0, dp(4), 0, 0) })
            row.addView(icon); row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val more = TextView(this).apply { text = "⋮"; textSize = 24f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(dp(12), 0, dp(8), 0); setOnClickListener { showDocMenu(doc) } }
            row.addView(more)
            row.setOnClickListener { openDoc(doc) }
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
    }

    private fun showDocMenu(doc: Doc) {
        val items = arrayOf("Open PDF", "Share PDF", "Export / Save a copy", "Rename", "Delete")
        AlertDialog.Builder(this).setTitle(doc.name).setItems(items) { _, which ->
            when (which) {
                0 -> openDoc(doc)
                1 -> shareDoc(doc)
                2 -> exportDoc(doc)
                3 -> renameDoc(doc)
                4 -> AlertDialog.Builder(this).setMessage("Delete ${doc.name} and its saved pages?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> deleteDoc(doc) }.show()
            }
        }.show()
    }

    private fun openDoc(doc: Doc) {
        val file = File(File(filesDir, "documents"), doc.pdfName)
        if (!file.exists()) { toast("PDF file not found"); return }
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (_: Exception) { toast("No PDF viewer found. Use Share PDF instead.") }
    }

    private fun shareDoc(doc: Doc) {
        val file = File(File(filesDir, "documents"), doc.pdfName)
        if (!file.exists()) { toast("PDF file not found"); return }
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivity(Intent.createChooser(intent, "Share ${doc.name}"))
    }

    private fun exportDoc(doc: Doc) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; putExtra(Intent.EXTRA_TITLE, "${safeName(doc.name)}.pdf") }
        exportTarget = doc
        exportLauncher.launch(intent)
    }
    private var exportTarget: Doc? = null
    private val exportLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri = result.data?.data ?: return@registerForActivityResult
            val doc = exportTarget ?: return@registerForActivityResult
            try {
                val source = File(File(filesDir, "documents"), doc.pdfName)
                contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(source).use { it.copyTo(out) } }
                toast("PDF exported successfully")
            } catch (e: Exception) { toast("Export failed: ${e.localizedMessage}") }
        }
        exportTarget = null
    }

    private fun renameDoc(doc: Doc) {
        val input = EditText(this).apply { setText(doc.name); setSelection(text.length); setPadding(dp(18), dp(10), dp(18), dp(10)) }
        AlertDialog.Builder(this).setTitle("Rename document").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            val value = input.text.toString().trim()
            if (value.isNotEmpty()) { doc.name = value; persistDocs(); renderDocs() } else toast("Enter a document name")
        }.show()
    }

    private fun deleteDoc(doc: Doc) {
        val dir = File(filesDir, "documents")
        File(dir, doc.pdfName).delete(); doc.pageNames.forEach { File(dir, it).delete() }
        docs.remove(doc); persistDocs(); renderDocs(); toast("Document deleted")
    }

    private fun showPdfTools() {
        AlertDialog.Builder(this).setTitle("PDF tools").setMessage("Ilam Scanner currently lets you scan multi-page documents, rename PDFs, share them, and export copies. Page crop, reorder and filters are available during scanning.")
            .setPositiveButton("Start scanning") { _, _ -> startScan() }.setNegativeButton("Close", null).show()
    }

    private fun loadDocs(): MutableList<Doc> {
        val prefs = getSharedPreferences("ilam_scanner", MODE_PRIVATE)
        val raw = prefs.getString("docs", "") ?: ""
        return raw.lineSequence().filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("|")
            if (p.size < 6) null else Doc(p[0], decode(p[1]), p[2], if (p[3].isBlank()) emptyList() else p[3].split(","), p[4].toIntOrNull() ?: 1, p[5].toLongOrNull() ?: 0L)
        }.toMutableList()
    }
    private fun persistDocs() {
        val raw = docs.joinToString("\n") { listOf(it.id, encode(it.name), it.pdfName, it.pageNames.joinToString(","), it.pageCount.toString(), it.created.toString()).joinToString("|") }
        getSharedPreferences("ilam_scanner", MODE_PRIVATE).edit().putString("docs", raw).apply()
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, 1) }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun formatDate(time: Long) = if (time == 0L) "Saved document" else SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(time))
    private fun safeName(s: String) = s.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifBlank { "Ilam_Scan" }
    private fun encode(s: String) = android.util.Base64.encodeToString(s.toByteArray(), android.util.Base64.NO_WRAP)
    private fun decode(s: String) = try { String(android.util.Base64.decode(s, android.util.Base64.DEFAULT)) } catch (_: Exception) { s }

    data class Doc(val id: String, var name: String, val pdfName: String, val pageNames: List<String>, val pageCount: Int, val created: Long)

    private class SimpleWatcher(val changed: () -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed() }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }
}
