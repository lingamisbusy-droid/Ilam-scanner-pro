# Ilam Scanner (Android)

An Android Studio Kotlin project for a document-scanning app.

## Included in v1.0
- Full document scanning flow powered by Google ML Kit Document Scanner
- Automatic edge detection, crop/rotate/filter controls supplied by the scanner UI
- Multi-page scans (up to 100 pages per session)
- Gallery import from inside the scanner
- PDF and JPEG page output
- Local app-private storage for saved PDFs and JPEG pages
- Recent documents list and search
- Open/share PDF, export a copy using Android's Save As dialog, rename and delete
- No camera or broad storage permission requested by this app; scanner UI is provided by Google Play services

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 36 (Android 16).
2. Open this folder (`IlamScanner`) in Android Studio.
3. Allow Gradle sync and install any prompted SDK/build tools.
4. Connect an Android phone with Google Play services, or use a supported emulator.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Requirements / notes
- Android 6.0 (API 23) or newer for this project.
- The ML Kit scanner is downloaded on demand by Google Play services; first launch may require internet.
- Google documents Android API 21+ and a minimum total device RAM of 1.7 GB for its scanner API.
- Scan and PDF generation require Google Play services. The scanner feature may not be available on devices without it.
- Scanned documents are stored inside the app's private files directory. Uninstalling the app removes those local files; export important PDFs to shared storage or cloud storage.
- The PDF viewer is an external Android app. If none is installed, use Share PDF.

## Current limitations
- PDF page editing after saving (reorder/delete individual pages), OCR/searchable PDF, password protection, cloud sync, and batch renaming are not included in this first build.
- The scan screen's capture, crop, rotation, cleanup and filters are provided by Google's scanner UI, rather than reimplemented as a custom camera screen.
